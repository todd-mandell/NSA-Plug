This is for all versions of the O.MG Cable, O.MG Adapter, and O.MG Plug



# [Setup Instructions & Latest Firmware](https://github.com/O-MG/O.MG-Firmware/wiki)



<img src="https://o.mg.lol/OMGCable-pkg.jpg" >